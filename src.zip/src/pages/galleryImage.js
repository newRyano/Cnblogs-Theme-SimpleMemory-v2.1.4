/**
 * UPDATES AND DOCS AT: https://github.com/BNDong
 * https://www.cnblogs.com/bndong/
 * @author: BNDong, dbnuo@foxmail.com
 * ----------------------------------------------
 * @describe: 相册图片详情页处理
 */

import comGallery from "./common/comGallery";

export default function main(_) {

    /**
     * 相册页公共处理
     */
    (() => {
        comGallery(_);
    })();

}