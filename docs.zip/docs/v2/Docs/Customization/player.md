# 播放器

播放器使用开源项目：[metowolf/MetingJS](https://github.com/metowolf/MetingJS)

如需使用播放器，请根据项目文档配置代码，添加至页脚Html代码中。

!> 版本 <=2.1.3 配置

!> 已知问题：使用此播放器插件，会导致博客园原有的页面锚点链接失效（主题设置的不受影响）！不影响基本使用，请大家权衡是否使用！

!> 目前发现受影响的有：
!>      1) Markdown 文章中 ```[toc]``` 生成的目录链接跳转。
!>      2) 博客园原有的返回顶部链接跳转。


?> 榜单ID获取 | 默认配置为热歌榜

![img](https://cdn.jsdelivr.net/gh/wangyang0210/pic/imgs/project/cnblogs/20221217233703.png)